    <footer id="main-footer" class="site-footer">
        <div class="container">
            <p>Copyright © 2017 Ka-Nying Shedrub Ling Development Trust. All rights reserved.</p>
            <ul class="social-links">
                <li><a href="" target="_blank"><img src="images/facebook.svg" alt="facebook"></a></li>
            </ul>
        </div>
    </footer>
    <!-- /site-footer -->

    <!--build:js js/scripts.min.js -->
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/modernizr.js"></script>
    <script type="text/javascript" src="js/owl.carousel.min.js"></script>
    <script type="text/javascript" src="js/jquery.gridder.js"></script>
    <script type="text/javascript" src="js/category-gridder.js"></script>
    <script type="text/javascript" src="js/custom.js"></script>
    <!-- endbuild -->
</body>
</html>