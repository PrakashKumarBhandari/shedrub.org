$(function () {
    // Call Gridder
    $(".gridder").gridderExpander({
        scroll: true,
        scrollOffset: 292,
        scrollTo: "panel", // panel or listitem
        animationSpeed: 400,
        animationEasing: "easeInOutExpo",
        showNav: false, // Show Navigation
    });
});
