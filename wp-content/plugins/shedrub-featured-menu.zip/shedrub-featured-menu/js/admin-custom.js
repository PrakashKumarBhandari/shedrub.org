jQuery(document).ready( function () { 
    jQuery("#pkb_add_new_items").click(function(){
        // alert("clicked");
        jQuery(".pkb_repeter_form").toggle();
    });

    
    jQuery("#pkb_save_content").click(function(){
        alert("Content Saved");
        //jQuery(".pkb_repeter_form").toggle();
    });


});

